import React, { useState } from 'react'
import { BRAND } from '../lib/tokens'
import Logo from './Logo'

/* ── Rich link type ─────────────────────────────────────────── */
interface RichLink {
  title:  string
  desc:   string
  badge?: string
  href:   string
  icon?:  string
  hot?:   boolean
}

/* ── Expandable section definition ──────────────────────────── */
interface FooterSection {
  heading:  string
  icon:     string
  summary:  string
  links:    RichLink[]
}

/* ── All footer sections ─────────────────────────────────────── */
const SECTIONS: FooterSection[] = [
  {
    heading: 'Product',
    icon: '🏗️',
    summary: 'Core platform features',
    links: [
      { icon:'🏠', title:'Lease Management',    href:'#platform',  desc:'AI-drafted leases, e-signatures, auto-renewals, expiry alerts. Cut lease admin by 80%.', badge:'Core' },
      { icon:'💳', title:'Rent Collection',     href:'#platform',  desc:'Auto-collect via M-Pesa, SWIFT, SEPA, Stripe, PayPal in 120+ currencies.',              badge:'Core' },
      { icon:'🔧', title:'Maintenance OS',      href:'#platform',  desc:'Predictive alerts, vendor dispatch, photo evidence log, cost tracking.', badge:'Popular' },
      { icon:'📊', title:'Analytics Dashboard', href:'#platform',  desc:'Live occupancy, yield, compliance, and cashflow across your full portfolio.',             },
      { icon:'🤖', title:'AI Copilot',          href:'#ai-copilot',desc:'Jurisdiction-aware assistant. Draft leases, check compliance, answer tenant queries instantly.', badge:'New', hot:true },
      { icon:'🌍', title:'Global Compliance',   href:'#platform',  desc:'Auto-updated regulation rules for 120+ countries. Zero compliance fines, guaranteed.',  },
      { icon:'📱', title:'Tenant Portal',       href:'#platform',  desc:'Branded self-service portal — pay rent, log issues, sign docs, view history.',          },
      { icon:'🔗', title:'Integrations',        href:'#platform',  desc:'Connect Xero, QuickBooks, Salesforce, Slack, Zapier and 200+ apps via API.',            },
    ],
  },
  {
    heading: 'Markets',
    icon: '🌐',
    summary: 'Localised for your country',
    links: [
      { icon:'🇬🇧', title:'United Kingdom',   href:'#markets', desc:'RICS-aligned compliance, AST leases, deposit protection, Section 21/8 notices.', badge:'Top market' },
      { icon:'🇦🇪', title:'UAE & Gulf',        href:'#markets', desc:'RERA-compliant contracts, Ejari registration, Tawtheeq, DIFC arbitration support.'        },
      { icon:'🇰🇪', title:'Kenya & East Africa',href:'#markets', desc:'M-Pesa native, county-level compliance, Rent Restriction Tribunal documentation.',       badge:'Fast growing' },
      { icon:'🇺🇸', title:'United States',     href:'#markets', desc:'State-by-state lease law, security deposit caps, eviction process guidance.',            },
      { icon:'🇦🇺', title:'Australia',         href:'#markets', desc:'State-level tenancy act compliance, bond lodgement, VCAT/NCAT documentation.',           },
      { icon:'🇸🇬', title:'Singapore',         href:'#markets', desc:'HDB & private lease compliance, stamp duty calculator, IPOS tenancy templates.',        },
      { icon:'🇿🇦', title:'South Africa',      href:'#markets', desc:'Rental Housing Act compliance, deposit auditing, CPA-aligned lease templates.',         },
      { icon:'🌍', title:'30+ More Markets',   href:'#markets', desc:'Canada, India, Germany, France, Nigeria, Ghana, Tanzania and growing rapidly.',          },
    ],
  },
  {
    heading: 'Solutions',
    icon: '⚡',
    summary: 'By portfolio type',
    links: [
      { icon:'🏢', title:'Large Portfolios',        href:'#platform', desc:'1,000+ units — bulk operations, multi-entity reporting, dedicated SLA.', badge:'Enterprise' },
      { icon:'🏘️', title:'Independent Landlords',   href:'#platform', desc:'1–10 units — simple, beautiful, no training required. Start in 5 min.' },
      { icon:'🏨', title:'Short-Term Rentals',       href:'#platform', desc:'Airbnb/VRBO sync, dynamic pricing, turnover scheduling, damage tracking.', hot:true },
      { icon:'🏬', title:'Commercial Properties',    href:'#platform', desc:'NNN leases, CAM reconciliation, rent escalation clauses, BOMA standards.' },
      { icon:'🎓', title:'Student Housing',          href:'#platform', desc:'Semester leases, guarantor management, room-mate billing splits.', badge:'Popular' },
      { icon:'🏥', title:'Social & Affordable',      href:'#platform', desc:'Housing benefit tracking, Universal Credit payments, council compliance.' },
      { icon:'🏦', title:'Institutional Investors',  href:'#platform', desc:'Asset management dashboards, IRR tracking, debt covenant monitoring.',    badge:'Enterprise' },
      { icon:'🔑', title:'Property Agents & PMs',    href:'#platform', desc:'Multi-client management, white-label portal, referral commissions.'     },
    ],
  },
  {
    heading: 'Academy',
    icon: '🎓',
    summary: 'Free courses & certifications',
    links: [
      { icon:'📚', title:'PM 101: Foundations',      href:'#academy', desc:'12-lesson free course covering leasing, rent collection, tenant comms.',  badge:'Free' },
      { icon:'🤖', title:'AI Copilot Masterclass',    href:'#academy', desc:'8 lessons: prompt engineering for leases, compliance, and market reports.', badge:'Free', hot:true },
      { icon:'⚖️', title:'Global Compliance Bootcamp', href:'#academy', desc:'20-lesson deep dive across UK, UAE, KE, US, AU — earn your certificate.', badge:'Certificate' },
      { icon:'💰', title:'Rent Growth Playbook',      href:'#academy', desc:'Evidence-based strategies to maximise yield while retaining great tenants.', badge:'Free' },
      { icon:'🔧', title:'Maintenance Mastery',       href:'#academy', desc:'Preventative programs that slash maintenance costs by up to 40%.', badge:'Free' },
      { icon:'📈', title:'Portfolio Analytics',       href:'#academy', desc:'Turn your data into insight: occupancy trends, yield optimisation, KPIs.', badge:'Pro' },
      { icon:'🌍', title:'Cross-Border Investing',    href:'#academy', desc:'How to structure, manage, and exit multi-jurisdiction property portfolios.', badge:'Pro' },
      { icon:'🏅', title:'easyTenancy Certified PM',  href:'#academy', desc:'Our flagship credential — recognised by 1,200+ employers in 45 countries.', badge:'Certificate', hot:true },
    ],
  },
  {
    heading: 'Resources',
    icon: '📖',
    summary: 'Guides, docs & tools',
    links: [
      { icon:'📄', title:'Lease Template Library',    href:'#',        desc:'200+ jurisdiction-specific lease templates, free to download and use.'        },
      { icon:'🧮', title:'ROI Calculator',            href:'#',        desc:'Model your portfolio returns with our interactive yield and ROI tool.', badge:'Popular' },
      { icon:'📰', title:'Property Market Blog',      href:'#',        desc:'Weekly insights on global rental markets, regulations, and trends.'           },
      { icon:'🎥', title:'Video Tutorials',           href:'#',        desc:'Step-by-step walkthroughs of every easyTenancy feature.', badge:'New'          },
      { icon:'🔌', title:'Developer API Docs',        href:'#',        desc:'REST API reference, webhooks, SDKs for Node, Python, Ruby, PHP.',             },
      { icon:'🆘', title:'Help Centre',               href:'#',        desc:'2,400+ articles, live chat support, community forum, and priority tickets.',   },
      { icon:'📊', title:'Benchmark Reports',         href:'#',        desc:'Annual Global Rental Market Report — free for all registered users.',        },
      { icon:'🤝', title:'Partner Directory',         href:'#',        desc:'Vetted accountants, lawyers, and surveyors in 40+ countries.', badge:'New'     },
    ],
  },
  {
    heading: 'Company',
    icon: '🏢',
    summary: 'About easyTenancy',
    links: [
      { icon:'ℹ️', title:'About Us',            href:'#', desc:'Our mission: make world-class property management accessible to every landlord, everywhere.'   },
      { icon:'💼', title:'Careers',             href:'#', desc:'We\'re hiring across engineering, product, sales and customer success.', badge:'10 open roles', hot:true },
      { icon:'📰', title:'Press & Media',       href:'#', desc:'Press kit, brand assets, and media enquiries.', badge:'Press'               },
      { icon:'🔒', title:'Security & Privacy',  href:'#', desc:'SOC 2 Type II, GDPR, CCPA, ISO 27001 compliant. Your data stays yours.'  },
      { icon:'⚖️', title:'Legal & Terms',       href:'#', desc:'Terms of service, privacy policy, DPA, and acceptable use policy.'       },
      { icon:'🌱', title:'Sustainability',       href:'#', desc:'Carbon-neutral since 2023. Our commitment to responsible property tech.' },
      { icon:'🤝', title:'Partnerships',         href:'#', desc:'Become an integration partner, referral partner, or white-label reseller.' },
      { icon:'📞', title:'Contact',             href:'#', desc:'Sales, support, billing, and press. We reply within 2 business hours.', badge:'Fast reply' },
    ],
  },
]

/* ── Single expandable section ───────────────────────────────── */
function FooterAccordion({ section }: { section: FooterSection }) {
  const [open, setOpen] = useState(false)

  return (
    <div style={{ borderBottom: '1px solid rgba(255,255,255,0.06)', paddingBottom: open ? 4 : 0 }}>
      <button
        className="footer-section-toggle"
        aria-expanded={open}
        onClick={() => setOpen(v => !v)}
        style={{
          padding: '16px 0',
          color: 'var(--white)',
          fontFamily: 'var(--font-head)',
          fontSize: 13,
          fontWeight: 700,
          textTransform: 'uppercase',
          letterSpacing: '.1em',
          background: 'none',
          border: 'none',
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          width: '100%',
        }}
      >
        <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span>{section.icon}</span>
          {section.heading}
        </span>
        <span className="chevron" style={{
          fontSize: 10, color: 'var(--mist)',
          transition: 'transform .3s cubic-bezier(0.4,0,0.2,1)',
          transform: open ? 'rotate(180deg)' : 'none',
        }}>▼</span>
      </button>

      {/* Summary shown when closed */}
      {!open && (
        <p style={{ fontSize: 12, color: 'var(--text3)', margin: '-4px 0 12px', paddingLeft: 24 }}>
          {section.summary}
        </p>
      )}

      {/* Rich links panel */}
      <div className={`footer-links-panel${open ? ' open' : ''}`}>
        <div style={{ display: 'flex', flexDirection: 'column', paddingBottom: 12 }}>
          {section.links.map(link => (
            <a
              key={link.title}
              href={link.href}
              className="footer-link-rich"
              onClick={e => e.preventDefault()}
            >
              <span className="flr-title">
                {link.icon && <span style={{ fontSize: 15 }}>{link.icon}</span>}
                {link.title}
                {link.badge && <span className="flr-badge">{link.badge}</span>}
                {link.hot && (
                  <span style={{ fontSize: 10, fontWeight: 700, padding: '2px 7px', borderRadius: 999, background: 'rgba(239,68,68,.15)', color: '#f87171', border: '1px solid rgba(239,68,68,.25)' }}>
                    Hot 🔥
                  </span>
                )}
              </span>
              <span className="flr-desc">{link.desc}</span>
            </a>
          ))}
        </div>
      </div>
    </div>
  )
}

/* ── Academy highlight row ────────────────────────────────────── */
function AcademyHighlight() {
  return (
    <div style={{
      background: 'linear-gradient(135deg, rgba(42,157,110,.12), rgba(26,109,181,.08))',
      border: '1px solid rgba(42,157,110,.22)',
      borderRadius: 20, padding: '32px 36px', marginBottom: 64,
      display: 'grid', gridTemplateColumns: '1fr auto', gap: 32, alignItems: 'center',
    }}>
      <div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
          <span style={{ fontSize: 28 }}>🎓</span>
          <span style={{
            fontFamily: 'var(--font-head)', fontSize: 20, fontWeight: 800,
            color: 'var(--white)', letterSpacing: '-0.4px',
          }}>
            easy<span style={{ color: BRAND.teal }}>Tenancy</span> Academy
          </span>
          <span style={{ background: 'rgba(42,157,110,.2)', color: BRAND.teal, border: `1px solid rgba(42,157,110,.3)`, borderRadius: 999, padding: '3px 10px', fontSize: 11, fontWeight: 700 }}>Free</span>
        </div>
        <p style={{ fontSize: 15, color: 'var(--text2)', lineHeight: 1.6, maxWidth: 520 }}>
          The world's only property management certification programme built for a global, AI-first world. 8 courses · 3 certificates · Recognised in 45 countries.
        </p>
        <div style={{ display: 'flex', gap: 24, marginTop: 14, flexWrap: 'wrap' }}>
          {[['12K+','Graduates'],['45','Countries recognized'],['100%','Free to start'],['4.9★','Avg rating']].map(([v,l])=>(
            <div key={l}>
              <div style={{ fontSize: 20, fontWeight: 800, color: 'var(--white)' }}>{v}</div>
              <div style={{ fontSize: 11, color: 'var(--text3)' }}>{l}</div>
            </div>
          ))}
        </div>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        <a href="#academy" onClick={e=>e.preventDefault()}
          style={{ background: 'var(--grad)', borderRadius: 14, padding: '12px 24px', fontSize: 14, fontWeight: 700, color: '#fff', textDecoration: 'none', textAlign: 'center', whiteSpace: 'nowrap' }}>
          Browse courses →
        </a>
        <a href="#academy" onClick={e=>e.preventDefault()}
          style={{ background: 'rgba(255,255,255,.06)', border: '1px solid rgba(255,255,255,.12)', borderRadius: 14, padding: '11px 24px', fontSize: 13, fontWeight: 600, color: 'var(--text2)', textDecoration: 'none', textAlign: 'center', whiteSpace: 'nowrap' }}>
          View certificates
        </a>
      </div>
    </div>
  )
}

/* ── Social links ─────────────────────────────────────────────── */
function Socials() {
  return (
    <div style={{ display: 'flex', gap: 10 }}>
      {[
        { label: 'X / Twitter', icon: '✕', href: '#' },
        { label: 'LinkedIn',    icon: 'in', href: '#' },
        { label: 'YouTube',     icon: '▶', href: '#' },
        { label: 'GitHub',      icon: '</>',href: '#' },
      ].map(s => (
        <a key={s.label} href={s.href} aria-label={s.label} onClick={e=>e.preventDefault()}
          style={{ width: 36, height: 36, borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(255,255,255,.06)', border: '1px solid rgba(255,255,255,.10)', color: 'var(--text2)', textDecoration: 'none', fontSize: 12, fontWeight: 700, transition: 'all .2s' }}
          onMouseEnter={e=>{(e.currentTarget as HTMLElement).style.background='rgba(26,109,181,.2)';(e.currentTarget as HTMLElement).style.color='var(--brand-blue-light)'}}
          onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.background='rgba(255,255,255,.06)';(e.currentTarget as HTMLElement).style.color='var(--text2)'}}>
          {s.icon}
        </a>
      ))}
    </div>
  )
}

/* ── Main Footer ──────────────────────────────────────────────── */
export default function Footer() {
  return (
    <footer style={{ borderTop: '1px solid rgba(255,255,255,.07)', paddingTop: 64, paddingBottom: 48, background: 'linear-gradient(180deg, transparent, rgba(0,0,0,.4))' }}>
      <div className="inner">

        {/* Academy spotlight */}
        <AcademyHighlight />

        {/* Branding column + link columns */}
        <div style={{ display: 'grid', gridTemplateColumns: '280px 1fr', gap: 64, marginBottom: 48 }}>

          {/* Brand column */}
          <div>
            <Logo size="md" variant="full" href={false} />
            <p style={{ fontSize: 13, color: 'var(--text2)', lineHeight: 1.7, marginTop: 16, marginBottom: 20 }}>
              The #1 Global Real Estate Operating System. Trusted by 52,000+ property managers across 120 countries.
            </p>
            <Socials />
            <div style={{ marginTop: 20, display: 'flex', flexDirection: 'column', gap: 6 }}>
              <a href="mailto:hello@easytenancy.io" onClick={e=>e.preventDefault()}
                style={{ fontSize: 13, color: 'var(--brand-blue-light)', textDecoration: 'none', display: 'flex', alignItems: 'center', gap: 6 }}>
                ✉ hello@easytenancy.io
              </a>
              <a href="tel:+442012345678" onClick={e=>e.preventDefault()}
                style={{ fontSize: 13, color: 'var(--text2)', textDecoration: 'none' }}>
                📞 +44 20 1234 5678
              </a>
            </div>
            {/* Trust badges */}
            <div style={{ marginTop: 24, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              {['SOC 2','GDPR','ISO 27001','CCPA'].map(b=>(
                <span key={b} style={{ fontSize: 10, fontWeight: 700, padding: '4px 8px', borderRadius: 6, background: 'rgba(255,255,255,.05)', border: '1px solid rgba(255,255,255,.08)', color: 'var(--text3)', letterSpacing: '.05em' }}>{b}</span>
              ))}
            </div>
          </div>

          {/* Expandable accordion columns */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '0 40px' }}>
            {SECTIONS.map(s => (
              <FooterAccordion key={s.heading} section={s} />
            ))}
          </div>
        </div>

        {/* Bottom bar */}
        <div style={{ borderTop: '1px solid rgba(255,255,255,.06)', paddingTop: 24, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12 }}>
          <p style={{ fontSize: 12, color: 'var(--text3)' }}>
            © {new Date().getFullYear()} easyTenancy Ltd · Registered in England & Wales · Company No. 12345678
          </p>
          <div style={{ display: 'flex', gap: 20 }}>
            {[['Privacy Policy','#'],['Terms of Service','#'],['Cookie Settings','#'],['Sitemap','#']].map(([l,h])=>(
              <a key={l} href={h} onClick={e=>e.preventDefault()}
                style={{ fontSize: 12, color: 'var(--text3)', textDecoration: 'none', transition: 'color .2s' }}
                onMouseEnter={e=>(e.currentTarget as HTMLElement).style.color='var(--text2)'}
                onMouseLeave={e=>(e.currentTarget as HTMLElement).style.color='var(--text3)'}>
                {l}
              </a>
            ))}
          </div>
        </div>

      </div>
    </footer>
  )
}
