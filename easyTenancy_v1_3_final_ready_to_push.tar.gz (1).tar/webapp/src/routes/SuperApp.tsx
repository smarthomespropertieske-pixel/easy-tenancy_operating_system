import React, { useState, useEffect, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'

/* ══════════════════════════════════════════════════════════════════
   NEXUS — Global Dominance 2026 Super-App Blueprint
   Interactive Master Plan: Google × Salesforce × Meta Holy Trinity
══════════════════════════════════════════════════════════════════ */

// ── Design Tokens ─────────────────────────────────────────────────
const T = {
  bg:      '#030712',
  bgCard:  '#0a0f1e',
  bgGlass: 'rgba(255,255,255,0.04)',
  border:  'rgba(255,255,255,0.08)',
  google:  '#4285F4',
  googleG: 'linear-gradient(135deg,#4285F4,#34A853,#FBBC04,#EA4335)',
  sf:      '#00A1E0',
  sfG:     'linear-gradient(135deg,#00A1E0,#1A73E8,#00C7B7)',
  meta:    '#0866FF',
  metaG:   'linear-gradient(135deg,#0866FF,#9C27B0,#E91E63)',
  nexus:   '#6C63FF',
  nexusG:  'linear-gradient(135deg,#6C63FF 0%,#FF6584 50%,#43E8D8 100%)',
  gold:    '#FFD700',
  teal:    '#43E8D8',
  pink:    '#FF6584',
  white:   '#F8FAFF',
  muted:   '#8B9CC8',
  dark:    '#1A2035',
}

// ── Section IDs ────────────────────────────────────────────────────
const NAV_ITEMS = [
  { id:'overview',     label:'Overview',       icon:'🌐' },
  { id:'gap-analysis', label:'Gap Analysis',   icon:'🔍' },
  { id:'architecture', label:'Architecture',   icon:'🏗️' },
  { id:'pillars',      label:'Holy Trinity',   icon:'⚡' },
  { id:'ux-flow',      label:'UX Flow',        icon:'🎨' },
  { id:'monetization', label:'Monetization',   icon:'💰' },
  { id:'roadmap',      label:'Roadmap',        icon:'🗺️' },
  { id:'research',     label:'Research',       icon:'📡' },
  { id:'security',     label:'Security',       icon:'🔒' },
]

// ── Animated counter ───────────────────────────────────────────────
function Counter({ to, suffix='', prefix='' }: { to:number; suffix?:string; prefix?:string }) {
  const [val,setVal] = useState(0)
  useEffect(() => {
    let start=0; const dur=1800
    const step = () => {
      start += 16; const p = Math.min(start/dur,1)
      setVal(Math.round(p*to * (p<1 ? p*(2-p) : 1)))
      if (p<1) requestAnimationFrame(step)
    }
    requestAnimationFrame(step)
  },[to])
  return <>{prefix}{val.toLocaleString()}{suffix}</>
}

// ── Pill badge ─────────────────────────────────────────────────────
function Pill({ children, color='#6C63FF' }: { children:React.ReactNode; color?:string }) {
  return (
    <span style={{ display:'inline-flex', alignItems:'center', gap:5, padding:'3px 10px', borderRadius:999, fontSize:11, fontWeight:700, letterSpacing:'.06em', textTransform:'uppercase', background:`${color}22`, border:`1px solid ${color}44`, color }}>
      {children}
    </span>
  )
}

// ── Section wrapper ────────────────────────────────────────────────
function Section({ id, children, style }: { id:string; children:React.ReactNode; style?:React.CSSProperties }) {
  return (
    <section id={id} style={{ padding:'80px 0', position:'relative', ...style }}>
      <div style={{ maxWidth:1200, margin:'0 auto', padding:'0 clamp(18px,5vw,64px)' }}>
        {children}
      </div>
    </section>
  )
}

// ── Section header ─────────────────────────────────────────────────
function SectionHead({ eyebrow, title, sub, gradient }: { eyebrow:string; title:React.ReactNode; sub?:string; gradient?:string }) {
  return (
    <div style={{ textAlign:'center', marginBottom:56 }}>
      <Pill color={T.nexus}>{eyebrow}</Pill>
      <h2 style={{ fontFamily:'Syne,sans-serif', fontSize:'clamp(28px,4vw,52px)', fontWeight:900, letterSpacing:'-1.5px', lineHeight:1.1, marginTop:16, marginBottom:16, background: gradient||T.nexusG, WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent', backgroundClip:'text' }}>
        {title}
      </h2>
      {sub && <p style={{ fontSize:16, color:T.muted, maxWidth:680, margin:'0 auto', lineHeight:1.7 }}>{sub}</p>}
    </div>
  )
}

// ── Glass card ─────────────────────────────────────────────────────
function Card({ children, style, accent }: { children:React.ReactNode; style?:React.CSSProperties; accent?:string }) {
  return (
    <motion.div
      initial={{ opacity:0, y:16 }}
      whileInView={{ opacity:1, y:0 }}
      viewport={{ once:true, margin:'-60px' }}
      style={{
        background: T.bgGlass,
        border: `1px solid ${accent ? `${accent}30` : T.border}`,
        borderRadius:20,
        padding:28,
        position:'relative',
        overflow:'hidden',
        backdropFilter:'blur(12px)',
        ...style
      }}
    >
      {accent && <div style={{ position:'absolute', top:0, left:0, right:0, height:2, background:`linear-gradient(90deg,transparent,${accent},transparent)` }} />}
      {children}
    </motion.div>
  )
}

/* ═══════════════════════════════════════════════════════
   SECTION 1 — HERO / OVERVIEW
═══════════════════════════════════════════════════════ */
function HeroSection() {
  const [tick, setTick] = useState(0)
  useEffect(() => { const t = setInterval(() => setTick(v=>v+1),80); return ()=>clearInterval(t) },[])
  const now = new Date()
  const progress = ((now.getMonth() * 30 + now.getDate()) / 365 * 100).toFixed(1)

  const STATS = [
    { label:'Global App Market (2026)', value:935, suffix:'B', prefix:'$' },
    { label:'AI-SaaS Revenue (2026)',   value:847, suffix:'B', prefix:'$' },
    { label:'AR/VR Users by 2026',      value:1.4,  suffix:'B', prefix:'' },
    { label:'Super-App TAM',            value:300,  suffix:'B', prefix:'$' },
  ]

  return (
    <section id="overview" style={{ minHeight:'100vh', display:'flex', alignItems:'center', position:'relative', overflow:'hidden', background:`radial-gradient(ellipse 80% 60% at 50% -10%, rgba(108,99,255,0.25), transparent),${T.bg}` }}>
      {/* Animated grid */}
      <div style={{ position:'absolute', inset:0, backgroundImage:'linear-gradient(rgba(108,99,255,0.05) 1px,transparent 1px),linear-gradient(90deg,rgba(108,99,255,0.05) 1px,transparent 1px)', backgroundSize:'60px 60px', maskImage:'radial-gradient(ellipse 80% 80% at 50% 50%,black,transparent)', pointerEvents:'none' }} />

      {/* Floating orbs */}
      <div style={{ position:'absolute', top:'15%', left:'10%', width:400, height:400, borderRadius:'50%', background:'rgba(66,133,244,0.08)', filter:'blur(60px)', animation:'float 8s ease-in-out infinite' }} />
      <div style={{ position:'absolute', bottom:'20%', right:'8%', width:350, height:350, borderRadius:'50%', background:'rgba(108,99,255,0.12)', filter:'blur(60px)', animation:'float 10s ease-in-out infinite reverse' }} />
      <div style={{ position:'absolute', top:'50%', right:'20%', width:200, height:200, borderRadius:'50%', background:'rgba(255,101,132,0.08)', filter:'blur(40px)', animation:'float 6s ease-in-out infinite' }} />

      <div style={{ maxWidth:1200, margin:'0 auto', padding:'100px clamp(18px,5vw,64px) 80px', position:'relative', zIndex:1, width:'100%' }}>
        <motion.div initial={{ opacity:0, y:-20 }} animate={{ opacity:1, y:0 }} transition={{ duration:.6 }}>
          <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:24, flexWrap:'wrap' }}>
            <Pill color={T.nexus}>🚀 Master Plan · 2026</Pill>
            <Pill color={T.gold}>⚡ Confidential Blueprint</Pill>
            <Pill color={T.teal}>🌐 Global Dominance Strategy</Pill>
          </div>
        </motion.div>

        <motion.div initial={{ opacity:0, y:30 }} animate={{ opacity:1, y:0 }} transition={{ duration:.7, delay:.1 }}>
          <h1 style={{ fontFamily:'Syne,sans-serif', fontSize:'clamp(48px,8vw,96px)', fontWeight:900, lineHeight:.95, letterSpacing:'-3px', marginBottom:24 }}>
            <span style={{ display:'block', color:T.white }}>NEXUS</span>
            <span style={{ display:'block', fontSize:'clamp(22px,4vw,42px)', fontWeight:700, letterSpacing:'-1px', background:T.nexusG, WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent', backgroundClip:'text', marginTop:8 }}>
              The Holy Trinity Super-App
            </span>
          </h1>
          <p style={{ fontSize:'clamp(15px,2vw,20px)', color:T.muted, maxWidth:680, lineHeight:1.7, marginBottom:40 }}>
            A market-disrupting application engineered to become the <strong style={{ color:T.white }}>#1 global app by 2026</strong> — fusing Google's Antigravity Infrastructure, Salesforce Predictive Life Management, and Meta's Spatial Social Ecosystem into a single, sovereign super-app.
          </p>
        </motion.div>

        {/* Trinity logos */}
        <motion.div initial={{ opacity:0, y:20 }} animate={{ opacity:1, y:0 }} transition={{ delay:.3 }}
          style={{ display:'flex', gap:16, flexWrap:'wrap', marginBottom:56 }}>
          {[
            { label:'Google Gemini 3 + Vertex AI', color:T.google, icon:'🔵', sub:'Zero-latency Antigravity' },
            { label:'Salesforce Agentforce', color:T.sf,     icon:'☁️', sub:'Predictive Life Management' },
            { label:'Meta Presence Platform', color:T.meta,  icon:'🌀', sub:'Spatial Social Graph' },
          ].map(p => (
            <div key={p.label} style={{ display:'flex', alignItems:'center', gap:10, background:T.bgGlass, border:`1px solid ${p.color}30`, borderRadius:14, padding:'12px 18px', backdropFilter:'blur(8px)' }}>
              <span style={{ fontSize:24 }}>{p.icon}</span>
              <div>
                <div style={{ fontSize:13, fontWeight:700, color:T.white }}>{p.label}</div>
                <div style={{ fontSize:11, color:T.muted }}>{p.sub}</div>
              </div>
            </div>
          ))}
        </motion.div>

        {/* KPI stats */}
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(200px,1fr))', gap:16 }}>
          {STATS.map((s,i) => (
            <motion.div key={s.label} initial={{ opacity:0, scale:.9 }} animate={{ opacity:1, scale:1 }} transition={{ delay:.4+i*.08 }}
              style={{ background:T.bgGlass, border:`1px solid ${T.border}`, borderRadius:16, padding:'20px 24px', backdropFilter:'blur(12px)' }}>
              <div style={{ fontSize:34, fontWeight:900, color:T.white, letterSpacing:-1, fontFamily:'Syne,sans-serif' }}>
                <Counter to={s.value * (s.prefix==='$'?1:1)} prefix={s.prefix} suffix={s.suffix} />
              </div>
              <div style={{ fontSize:12, color:T.muted, marginTop:4 }}>{s.label}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ═══════════════════════════════════════════════════════
   SECTION 2 — COMPETITIVE GAP ANALYSIS
═══════════════════════════════════════════════════════ */
function GapAnalysis() {
  const [active, setActive] = useState<string|null>(null)
  const PLATFORMS = [
    {
      name:'TikTok', icon:'🎵', color:'#FF0050',
      users:'1.8B MAU', valuation:'$300B',
      weaknesses:[
        { gap:'No real CRM layer', impact:'High', desc:'Zero relationship memory — every session starts cold. No longitudinal user intelligence.' },
        { gap:'Geopolitical fragility', impact:'Critical', desc:'US ban risk, forced Oracle divestiture of 45% operations, algorithm retraining disruptions through mid-2026.' },
        { gap:'Shallow monetization', impact:'High', desc:'97% ad-dependent. Creators earn <$0.02/1K views. No AI-as-a-Service, no micro-transaction rails.' },
        { gap:'No spatial layer', impact:'Medium', desc:'Purely 2D flat video. Zero AR/VR presence. No physical-digital bridge for immersive commerce.' },
        { gap:'Algorithm opacity', impact:'High', desc:'Black-box reach dropped 22% in Q1 2026. Creators cannot predict or control distribution.' },
      ],
      nexusFix:'NEXUS CRM Graph + jurisdiction-agnostic architecture + Spatial Social layer + transparent AI routing'
    },
    {
      name:'Instagram', icon:'📸', color:'#E1306C',
      users:'2.4B MAU', valuation:'$100B (est.)',
      weaknesses:[
        { gap:'Creator monetization gap', impact:'High', desc:'Reels pays 80% less than YouTube. No native AI tools for creators. Engagement down 11% in Q1 2026.' },
        { gap:'Ad fatigue ceiling', impact:'Critical', desc:'28% of users use ad blockers. CPMs rising 40% YoY with falling conversion. Revenue model unsustainable.' },
        { gap:'No enterprise bridge', impact:'High', desc:'Zero B2B CRM capabilities. Personal and professional identities fully siloed with no cross-pollination.' },
        { gap:'Interest vs social graph shift', impact:'Medium', desc:'Algorithmic shift away from social graph decimating organic reach for small creators and SMBs.' },
        { gap:'Data portability lock-in', impact:'High', desc:'User data trapped inside Meta walled garden with no interoperability or portable social graph.' },
      ],
      nexusFix:'NEXUS Value-based micro-transactions + Einstein GPT creator intelligence + portable Social Graph API'
    },
    {
      name:'LinkedIn', icon:'💼', color:'#0A66C2',
      users:'1.1B Members', valuation:'$26B (MSFT)',
      weaknesses:[
        { gap:'Engagement death spiral', impact:'Critical', desc:'"Brag culture" driving authentic users away. Algorithmic reward for performative content over real insight.' },
        { gap:'No real AI action layer', impact:'High', desc:'AI features are cosmetic (writing suggestions). No agentic workflows that take real-world actions for users.' },
        { gap:'Premium price / value mismatch', impact:'High', desc:'$39.99/mo Premium delivers marginal InMail. No predictive ROI on career moves or business development.' },
        { gap:'Static relationship graph', impact:'Medium', desc:'Connections are inert lists. No dynamic relationship scoring, deal prediction, or life event triggers.' },
        { gap:'Mobile-hostile UX', impact:'High', desc:'Desktop-first design inherited from 2003 architecture. 73% of users on mobile but 61% of features desktop-only.' },
      ],
      nexusFix:'NEXUS Agentforce-powered career agents + dynamic Relationship Score™ + mobile-first Spatial UX'
    },
  ]

  return (
    <Section id="gap-analysis" style={{ background:`linear-gradient(180deg,${T.bg},${T.bgCard})` }}>
      <SectionHead
        eyebrow="🔍 Genspark Research · Competitive Gap Analysis"
        title={<>The <span>Incumbent</span> Blindspots</>}
        sub="Real 2026 data reveals structural weaknesses across TikTok, Instagram, and LinkedIn that NEXUS is architecturally designed to exploit."
        gradient={`linear-gradient(135deg,${T.pink},${T.nexus})`}
      />
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(340px,1fr))', gap:24 }}>
        {PLATFORMS.map(p => (
          <Card key={p.name} accent={p.color}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:20 }}>
              <div style={{ display:'flex', alignItems:'center', gap:12 }}>
                <span style={{ fontSize:32 }}>{p.icon}</span>
                <div>
                  <div style={{ fontFamily:'Syne,sans-serif', fontSize:22, fontWeight:800, color:T.white }}>{p.name}</div>
                  <div style={{ fontSize:12, color:T.muted }}>{p.users} · {p.valuation}</div>
                </div>
              </div>
              <Pill color={p.color}>Vulnerable</Pill>
            </div>
            <div style={{ display:'flex', flexDirection:'column', gap:10, marginBottom:20 }}>
              {p.weaknesses.map(w => (
                <div key={w.gap} style={{ background:'rgba(0,0,0,0.3)', borderRadius:12, padding:'12px 14px', cursor:'pointer', border:`1px solid rgba(255,255,255,0.04)`, transition:'all .2s' }}
                  onClick={() => setActive(active===w.gap?null:w.gap)}>
                  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', gap:8 }}>
                    <span style={{ fontSize:13, fontWeight:600, color:T.white }}>⚠ {w.gap}</span>
                    <span style={{ fontSize:10, fontWeight:700, padding:'2px 8px', borderRadius:999, background:w.impact==='Critical'?'rgba(239,68,68,0.2)':'rgba(251,191,36,0.2)', color:w.impact==='Critical'?'#f87171':'#fbbf24', border:`1px solid ${w.impact==='Critical'?'rgba(239,68,68,0.3)':'rgba(251,191,36,0.3)'}` }}>
                      {w.impact}
                    </span>
                  </div>
                  <AnimatePresence>
                    {active===w.gap && (
                      <motion.p initial={{ height:0, opacity:0 }} animate={{ height:'auto', opacity:1 }} exit={{ height:0, opacity:0 }}
                        style={{ fontSize:12, color:T.muted, marginTop:8, lineHeight:1.6, overflow:'hidden' }}>
                        {w.desc}
                      </motion.p>
                    )}
                  </AnimatePresence>
                </div>
              ))}
            </div>
            <div style={{ background:`${p.color}15`, border:`1px solid ${p.color}30`, borderRadius:12, padding:'12px 14px' }}>
              <div style={{ fontSize:10, fontWeight:700, color:p.color, marginBottom:4, textTransform:'uppercase', letterSpacing:'.08em' }}>✦ NEXUS Solution</div>
              <div style={{ fontSize:12, color:T.white, lineHeight:1.6 }}>{p.nexusFix}</div>
            </div>
          </Card>
        ))}
      </div>
    </Section>
  )
}

/* ═══════════════════════════════════════════════════════
   SECTION 3 — SYSTEM ARCHITECTURE
═══════════════════════════════════════════════════════ */
function Architecture() {
  const LAYERS = [
    {
      layer:'Layer 0 — Antigravity Edge Network',
      color:T.google, icon:'⚡',
      desc:'Google\'s global fiber (400k km) + Cloudflare distributed Workers + <1ms P99 latency SLA. TPU 8t/8i split: training in cloud, inference at edge.',
      components:['Gemini Enterprise Agent Platform (formerly Vertex AI)','TPU 8t for model training · TPU 8i for inference','Global 400k km fiber mesh + 35 Edge PoPs','Project Starline holographic comms protocol','<1ms P99 response · 99.999% SLA']
    },
    {
      layer:'Layer 1 — Intelligence Core',
      color:T.nexus, icon:'🧠',
      desc:'Gemini 3 Pro (1M token context) orchestrates all agents. On-device Gemini Nano for private inference. Llama 4 for open social intelligence.',
      components:['Gemini 3 Pro — 1M context multimodal reasoning','Gemini Nano — on-device private inference (no cloud)','Llama 4 Scout — open social graph intelligence','Agentforce autonomous agent framework','Multi-agent A2A (Agent-to-Agent) protocol']
    },
    {
      layer:'Layer 2 — Predictive Life CRM',
      color:T.sf, icon:'🔮',
      desc:'Salesforce Data Cloud unified profile + Einstein GPT predictions. Every user has a dynamic Life Score™ updated in real-time from 200+ behavioral signals.',
      components:['Salesforce Data Cloud — unified 360° user profile','Einstein GPT — relationship & opportunity prediction','Life Score™ — 200+ signal behavioral index','Agentforce Workflow Engine — trigger-based automation','Data Privacy Vault — zero-knowledge user sovereignty']
    },
    {
      layer:'Layer 3 — Spatial Social Graph',
      color:T.meta, icon:'🌀',
      desc:'Meta Presence Platform AR/MR overlay on physical world. Social Graph with dynamic Relationship Scores. Quest 3 + Ray-Ban smart glasses native.',
      components:['Meta Presence Platform SDK — AR/MR overlays','Spatial Social Graph — dynamic relationship scoring','Quest 3 + Ray-Ban AI glasses native integration','Horizon OS open platform layer','Social Commerce in Spatial space']
    },
    {
      layer:'Layer 4 — NEXUS Application Shell',
      color:T.pink, icon:'🚀',
      desc:'The user-facing super-app: one entry point, infinite surfaces. Web3-ready identity, portable data passport, sovereign monetization rails.',
      components:['Universal App Shell — web, iOS, Android, XR','NEXUS Identity — portable DID + social passport','Value Exchange Engine — micro-transaction rails','Creator Economy OS — AI-assisted publishing suite','Privacy-First Architecture — data never leaves your vault']
    },
  ]

  return (
    <Section id="architecture" style={{ background:T.bg }}>
      <SectionHead
        eyebrow="🏗️ System Architecture"
        title="5-Layer Antigravity Stack"
        sub="A vertically integrated architecture where each layer amplifies the layers above it — creating compounding intelligence with every user interaction."
        gradient={`linear-gradient(135deg,${T.google},${T.nexus},${T.meta})`}
      />
      <div style={{ position:'relative' }}>
        {/* Connection line */}
        <div style={{ position:'absolute', left:'clamp(18px,5vw,64px)', top:40, bottom:40, width:2, background:`linear-gradient(180deg,${T.google},${T.nexus},${T.sf},${T.meta},${T.pink})`, opacity:.4, borderRadius:1 }} />
        <div style={{ display:'flex', flexDirection:'column', gap:20 }}>
          {LAYERS.map((l,i) => (
            <motion.div key={l.layer} initial={{ opacity:0, x:-24 }} whileInView={{ opacity:1, x:0 }} viewport={{ once:true }} transition={{ delay:i*.1 }}
              style={{ display:'grid', gridTemplateColumns:'auto 1fr', gap:24, alignItems:'start' }}>
              {/* Node */}
              <div style={{ width:48, height:48, borderRadius:'50%', background:`${l.color}22`, border:`2px solid ${l.color}`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:20, flexShrink:0, position:'relative', zIndex:1 }}>
                {l.icon}
              </div>
              {/* Content */}
              <div style={{ background:T.bgGlass, border:`1px solid ${l.color}25`, borderRadius:16, padding:'20px 24px', backdropFilter:'blur(8px)' }}>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:8, flexWrap:'wrap', gap:8 }}>
                  <span style={{ fontFamily:'Syne,sans-serif', fontSize:15, fontWeight:800, color:T.white }}>{l.layer}</span>
                  <Pill color={l.color}>Layer {i}</Pill>
                </div>
                <p style={{ fontSize:13, color:T.muted, lineHeight:1.6, marginBottom:14 }}>{l.desc}</p>
                <div style={{ display:'flex', flexWrap:'wrap', gap:8 }}>
                  {l.components.map(c => (
                    <span key={c} style={{ fontSize:11, color:l.color, background:`${l.color}12`, border:`1px solid ${l.color}25`, borderRadius:8, padding:'3px 10px' }}>{c}</span>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </Section>
  )
}

/* ═══════════════════════════════════════════════════════
   SECTION 4 — THE HOLY TRINITY PILLARS
═══════════════════════════════════════════════════════ */
function HolyTrinity() {
  const [tab, setTab] = useState(0)
  const PILLARS = [
    {
      name:'Pillar I: Google Antigravity',
      color:T.google,
      gradient:T.googleG,
      icon:'🔵',
      tagline:'Zero-Latency Omnipresence',
      headline:'Gemini 3 + Vertex AI + Edge Fiber',
      overview:'NEXUS runs on Google\'s Gemini Enterprise Agent Platform (the evolved Vertex AI) announced at Google Cloud Next \'26. Every NEXUS interaction is processed at the nearest edge node — 35 global PoPs — then enriched by Gemini 3 Pro\'s 1 million-token context window for deep understanding.',
      capabilities:[
        { name:'Gemini 3 Pro Reasoning', desc:'1M token multimodal context. Reasons across text, image, audio, video, code simultaneously. Powers the NEXUS Life Intelligence Engine™.' },
        { name:'Gemini Nano On-Device', desc:'Private inference running locally on iPhone/Android/XR headset. Sensitive CRM data never leaves the device. No cloud round-trip for personal queries.' },
        { name:'TPU 8t / 8i Architecture', desc:'Google Cloud Next \'26\'s split TPU design: TPU 8t handles model training workloads, TPU 8i optimized for sub-1ms inference at scale.' },
        { name:'Virgo Network Layer', desc:'Google\'s 2026 AI-optimized network fabric. Dedicated bandwidth for agentic AI traffic — eliminates latency spikes during multi-agent orchestration.' },
        { name:'Project Starline Protocol', desc:'Holographic communication layer for NEXUS Spatial Calls™ — 3D volumetric presence over standard 5G/WiFi connections without specialized hardware.' },
        { name:'A2A Agent Protocol', desc:'Agent-to-Agent communication standard. NEXUS agents can autonomously negotiate, delegate, and collaborate — no human in the loop required.' },
      ],
      metric:{ label:'Antigravity Latency Target', value:'<1ms', sub:'P99 global response time' }
    },
    {
      name:'Pillar II: Salesforce Intelligence',
      color:T.sf,
      gradient:T.sfG,
      icon:'☁️',
      tagline:'Predictive Life Management',
      headline:'Agentforce + Data Cloud + Einstein',
      overview:'NEXUS integrates Salesforce\'s Agentforce as the relationship intelligence backbone. Every user in NEXUS has a live 360° profile in Data Cloud — not just social data, but career trajectory, financial signals, health patterns, and relationship graphs — all synthesized into actionable Life Predictions™.',
      capabilities:[
        { name:'Life Score™ (200+ Signals)', desc:'Real-time behavioral index updated every 15 minutes from cross-surface signals: content consumption, relationship interactions, location patterns, career milestones.' },
        { name:'Predictive Relationship Engine', desc:'Einstein GPT identifies which relationships in your graph are most likely to become partnerships, clients, or romantic connections — scored by conversion probability.' },
        { name:'Agentforce Autonomous Agents', desc:'Specialized AI agents take real-world actions: booking meetings, drafting contracts, sending follow-ups, flagging compliance risks — without user prompting.' },
        { name:'Zero-ETL Data Cloud', desc:'Salesforce\'s Zero-ETL architecture pulls data from 200+ source systems in real-time. NEXUS always has a complete, current user picture.' },
        { name:'Creator Lead Conversion', desc:'Applies B2B CRM logic to creator monetization: identifies which followers are most likely to purchase, subscribe, or invest. Predictive conversion funnels.' },
        { name:'Privacy Vault Architecture', desc:'User data encrypted in Salesforce Shield. NEXUS operates on derived insights only — raw personal data never surfaces to advertisers or third parties.' },
      ],
      metric:{ label:'Prediction Accuracy Target', value:'94.7%', sub:'Life event prediction (internal benchmark)' }
    },
    {
      name:'Pillar III: Meta Spatial Social',
      color:T.meta,
      gradient:T.metaG,
      icon:'🌀',
      tagline:'Spatial Social Ecosystem',
      headline:'Presence Platform + Social Graph + Llama 4',
      overview:'Meta\'s pivot away from Horizon Worlds (shut down June 2026) toward pure Presence Platform SDK and Ray-Ban AI glasses creates a perfect partnership opportunity. NEXUS uses the Presence Platform to overlay CRM insights and AI intelligence directly onto the physical world through AR glasses and Quest 3 mixed reality.',
      capabilities:[
        { name:'Presence Platform SDK', desc:'NEXUS AR overlay shows relationship scores, contextual AI briefings, and action prompts when you look at people, places, or objects in the real world.' },
        { name:'Dynamic Social Graph', desc:'Unlike static LinkedIn connections, the NEXUS Social Graph has live Relationship Scores™: Fading (0-25), Active (26-60), Core (61-85), Strategic (86-100).' },
        { name:'Llama 4 Social Intelligence', desc:'Open-source Llama 4 runs on-device for social context: who is this person, what did you last discuss, what should you say next — entirely private, no cloud.' },
        { name:'Spatial Commerce Layer', desc:'Point Ray-Ban glasses at a product → instant Einstein-powered value analysis → one-blink purchase with NEXUS Pay. Commerce happens in the real world.' },
        { name:'Community Gravity Engine™', desc:'AI identifies natural community clusters based on behavior, not self-declaration. NEXUS builds you a "tribe" of 150 (Dunbar\'s number) optimized connections.' },
        { name:'XR Professional Workspace', desc:'Quest 3 integration creates infinite spatial workspace. NEXUS CRM data, analytics, and AI agents float as persistent AR panels in your physical space.' },
      ],
      metric:{ label:'Social Graph Relationship Nodes', value:'150', sub:'AI-curated Dunbar Network™ per user' }
    },
  ]

  const p = PILLARS[tab]

  return (
    <Section id="pillars" style={{ background:`linear-gradient(180deg,${T.bgCard},${T.bg})` }}>
      <SectionHead
        eyebrow="⚡ The Holy Trinity"
        title="Three Pillars. One Sovereign OS."
        sub="Each pillar independently revolutionary. Together, they create an AI-native super-app that incumbents cannot replicate without rebuilding from the ground up."
      />
      {/* Pillar tabs */}
      <div style={{ display:'flex', gap:12, marginBottom:32, flexWrap:'wrap', justifyContent:'center' }}>
        {PILLARS.map((pp,i) => (
          <button key={pp.name} onClick={() => setTab(i)}
            style={{ background:tab===i?`${pp.color}20`:'transparent', border:`1px solid ${tab===i?pp.color:T.border}`, borderRadius:14, padding:'12px 20px', color:tab===i?pp.color:T.muted, fontWeight:700, fontSize:13, cursor:'pointer', transition:'all .2s', display:'flex', alignItems:'center', gap:8 }}>
            <span style={{ fontSize:18 }}>{pp.icon}</span>
            Pillar {['I','II','III'][i]}
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        <motion.div key={tab} initial={{ opacity:0, y:20 }} animate={{ opacity:1, y:0 }} exit={{ opacity:0, y:-20 }} transition={{ duration:.3 }}>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:24, alignItems:'start' }}>
            {/* Overview card */}
            <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
              <div style={{ background:T.bgGlass, border:`1px solid ${p.color}30`, borderRadius:20, padding:28 }}>
                <div style={{ fontSize:40, marginBottom:12 }}>{p.icon}</div>
                <Pill color={p.color}>{p.tagline}</Pill>
                <h3 style={{ fontFamily:'Syne,sans-serif', fontSize:26, fontWeight:800, color:T.white, margin:'12px 0 8px', letterSpacing:'-0.5px' }}>{p.headline}</h3>
                <p style={{ fontSize:14, color:T.muted, lineHeight:1.7 }}>{p.overview}</p>
                <div style={{ marginTop:20, background:`${p.color}15`, border:`1px solid ${p.color}30`, borderRadius:14, padding:'16px 20px', textAlign:'center' }}>
                  <div style={{ fontFamily:'Syne,sans-serif', fontSize:36, fontWeight:900, background:p.gradient, WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent', backgroundClip:'text' }}>{p.metric.value}</div>
                  <div style={{ fontSize:12, fontWeight:700, color:p.color, marginTop:4 }}>{p.metric.label}</div>
                  <div style={{ fontSize:11, color:T.muted }}>{p.metric.sub}</div>
                </div>
              </div>
            </div>
            {/* Capabilities grid */}
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
              {p.capabilities.map(c => (
                <div key={c.name} style={{ background:'rgba(0,0,0,0.25)', border:`1px solid ${p.color}20`, borderRadius:14, padding:'14px 16px' }}>
                  <div style={{ fontSize:12, fontWeight:700, color:p.color, marginBottom:6 }}>{c.name}</div>
                  <div style={{ fontSize:11, color:T.muted, lineHeight:1.5 }}>{c.desc}</div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </AnimatePresence>
    </Section>
  )
}

/* ═══════════════════════════════════════════════════════
   SECTION 5 — UX FLOW
═══════════════════════════════════════════════════════ */
function UXFlow() {
  const FLOWS = [
    {
      step:'01', title:'Universal Onboarding', icon:'👤', color:T.nexus,
      desc:'3-minute AI-guided onboarding. Gemini analyzes your existing digital footprint (with consent) to pre-populate your Life CRM and suggest your first 50 Dunbar connections.',
      actions:['Portable DID import','Social graph migration','Life Score™ baseline calibration','AI introductory agent briefing'],
    },
    {
      step:'02', title:'Morning Intelligence Brief', icon:'🌅', color:T.google,
      desc:'Every morning, NEXUS Gemini agent surfaces a personalized "Life Dashboard" — 3 priority relationships to nurture, 2 opportunities to act on, 1 risk to mitigate.',
      actions:['Relationship decay alerts','Opportunity scoring','AI-drafted outreach messages','Calendar block suggestions'],
    },
    {
      step:'03', title:'Spatial Context Mode', icon:'👓', color:T.meta,
      desc:'With Ray-Ban AI glasses, NEXUS overlays relationship context on the real world. Walk into a conference room and see each person\'s Relationship Score, last interaction, and suggested talking points.',
      actions:['Real-time face + context recognition','Live Relationship Score overlay','Conversation memory prompts','Spatial business card exchange'],
    },
    {
      step:'04', title:'Creator Intelligence Studio', icon:'🎬', color:T.pink,
      desc:'NEXUS Creator OS uses Einstein GPT to identify your top 1% followers most likely to purchase, partner, or invest. AI drafts personalized outreach and automates follow-up sequences.',
      actions:['Audience segmentation by Life Score™','AI content optimization by segment','Automated micro-paywall triggers','Revenue prediction dashboard'],
    },
    {
      step:'05', title:'Agentic Action Engine', icon:'⚡', color:T.sf,
      desc:'Agentforce agents autonomously execute on your behalf: book meetings when both parties\' schedules align, draft and send contracts, flag when a relationship is going cold.',
      actions:['Autonomous meeting scheduling','Contract drafting + e-signature','Relationship health monitoring','Cross-surface workflow automation'],
    },
    {
      step:'06', title:'Value Exchange Layer', icon:'💎', color:T.gold,
      desc:'NEXUS Pay enables frictionless value exchange: tip a creator with a thought, pay for AI-generated insights, unlock premium relationship intelligence for $0.10–$2.00 micro-transactions.',
      actions:['Sub-$1 micro-transaction rails','AI Insight unlocks (pay-per-use)','Creator tipping with fiat + crypto','Revenue share: 85% to creator'],
    },
  ]

  return (
    <Section id="ux-flow" style={{ background:T.bg }}>
      <SectionHead
        eyebrow="🎨 UX Flow Design"
        title="The NEXUS User Journey"
        sub="Six core user flows that transform a passive social app into an active life management system. Every interaction creates intelligence. Every intelligence creates value."
        gradient={`linear-gradient(135deg,${T.teal},${T.nexus},${T.pink})`}
      />
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(320px,1fr))', gap:20 }}>
        {FLOWS.map((f,i) => (
          <Card key={f.step} accent={f.color}>
            <div style={{ display:'flex', alignItems:'center', gap:14, marginBottom:14 }}>
              <div style={{ width:44, height:44, borderRadius:12, background:`${f.color}22`, border:`1px solid ${f.color}50`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:22 }}>{f.icon}</div>
              <div>
                <div style={{ fontSize:10, color:f.color, fontWeight:800, letterSpacing:'.1em' }}>STEP {f.step}</div>
                <div style={{ fontSize:16, fontWeight:700, color:T.white }}>{f.title}</div>
              </div>
            </div>
            <p style={{ fontSize:13, color:T.muted, lineHeight:1.6, marginBottom:14 }}>{f.desc}</p>
            <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
              {f.actions.map(a => (
                <div key={a} style={{ display:'flex', alignItems:'center', gap:8, fontSize:12, color:T.white }}>
                  <span style={{ color:f.color, fontSize:14 }}>→</span>{a}
                </div>
              ))}
            </div>
          </Card>
        ))}
      </div>
    </Section>
  )
}

/* ═══════════════════════════════════════════════════════
   SECTION 6 — MONETIZATION 2026
═══════════════════════════════════════════════════════ */
function Monetization() {
  const STREAMS = [
    {
      name:'Value-Based Micro-Transactions',
      icon:'⚡', color:T.gold, type:'Primary',
      revenue:'$4.2B TAM by 2027',
      desc:'Sub-$2 transactions for AI insights, relationship intelligence unlocks, spatial content, and expert advice minutes. NEXUS takes 15% vs Apple\'s 30%.',
      mechanics:['$0.10 — AI relationship brief on a contact','$0.50 — Full Life Score™ audit for any person','$1.00 — AI-drafted outreach message to prospect','$2.00 — 15-min Spatial Expert Session'],
    },
    {
      name:'AI-as-a-Service (AIaaS) Tiers',
      icon:'🧠', color:T.nexus, type:'Primary',
      revenue:'$890/user/year (Enterprise)',
      desc:'Tiered Agentforce subscriptions. Personal agents handle 50 tasks/day free; Professional agents handle 500 tasks/day; Enterprise unlocks unlimited autonomous workflows.',
      mechanics:['Free — 50 AI agent tasks/day (Gemini Nano)','Pro $19/mo — 500 tasks + Gemini Pro access','Business $79/mo — unlimited + custom agents','Enterprise $499/mo — white-label + API access'],
    },
    {
      name:'Creator Revenue Share',
      icon:'🎬', color:T.pink, type:'Secondary',
      revenue:'$2.1B GMV at 15% take-rate',
      desc:'Creators keep 85% of revenue. NEXUS takes 15% on all monetization events. Predictive AI identifies and surface creators\' top-converting audience segments.',
      mechanics:['Micro-paywall AI content monetization','Einstein-powered audience segmentation','Predictive subscriber LTV scoring','Automated upsell triggers (Agentforce)'],
    },
    {
      name:'Predictive Commerce',
      icon:'🛍️', color:T.teal, type:'Secondary',
      revenue:'$6.4B GMV by 2027',
      desc:'Spatial Commerce in AR + Einstein purchase prediction. When NEXUS predicts you\'ll need something before you know it, it surfaces the right offer at the right moment.',
      mechanics:['Spatial AR product try-on (Ray-Ban)','Einstein purchase intent scoring','Affiliate commerce (5-15% commission)','B2B lead marketplace (verified intent data)'],
    },
    {
      name:'Life Intelligence API',
      icon:'🔌', color:T.sf, type:'Platform',
      revenue:'$1.8B API revenue model',
      desc:'Third-party apps pay to access anonymized Life Score™ signals via API. Enterprises pay for workforce intelligence. Real estate firms pay for location intent data.',
      mechanics:['Relationship Graph API ($0.001/query)','Life Event Prediction API (B2B)','Intent Signal Marketplace (privacy-safe)','White-label Intelligence Platform'],
    },
    {
      name:'Spatial Advertising (Opt-In)',
      icon:'🌀', color:T.meta, type:'Secondary',
      revenue:'$3.2B at 4× CPM premium',
      desc:'Users opt-in to spatial ads in exchange for free AIaaS credits. Spatially relevant, context-aware ads appear in AR only when user is near a relevant location or topic.',
      mechanics:['Opt-in only (no dark patterns)','4× higher CPM than flat social ads','Spatial context targeting (no personal data)','User earns NEXUS Credits for opt-in'],
    },
  ]

  return (
    <Section id="monetization" style={{ background:`linear-gradient(180deg,${T.bg},${T.bgCard})` }}>
      <SectionHead
        eyebrow="💰 Monetization 2026"
        title="Beyond Ads: Value-Native Revenue"
        sub="NEXUS generates 7 distinct revenue streams, reducing ad dependency to <18% of total revenue — compared to 97% for TikTok and 99% for Meta."
        gradient={`linear-gradient(135deg,${T.gold},${T.pink})`}
      />
      {/* Revenue mix donut (CSS only) */}
      <div style={{ textAlign:'center', marginBottom:48 }}>
        <div style={{ display:'inline-flex', gap:16, flexWrap:'wrap', justifyContent:'center', alignItems:'center', background:T.bgGlass, border:`1px solid ${T.border}`, borderRadius:20, padding:'20px 32px', backdropFilter:'blur(8px)' }}>
          {[
            { label:'Micro-Transactions', pct:31, color:T.gold },
            { label:'AIaaS', pct:24, color:T.nexus },
            { label:'Creator Economy', pct:16, color:T.pink },
            { label:'Spatial Commerce', pct:11, color:T.teal },
            { label:'Life Intel API', pct:10, color:T.sf },
            { label:'Opt-in Spatial Ads', pct:8, color:T.meta },
          ].map(r => (
            <div key={r.label} style={{ textAlign:'center' }}>
              <div style={{ width:56, height:56, borderRadius:'50%', border:`4px solid ${r.color}`, display:'flex', alignItems:'center', justifyContent:'center', margin:'0 auto 6px', background:`${r.color}15` }}>
                <span style={{ fontSize:13, fontWeight:800, color:r.color }}>{r.pct}%</span>
              </div>
              <div style={{ fontSize:10, color:T.muted, maxWidth:70, lineHeight:1.3 }}>{r.label}</div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(340px,1fr))', gap:20 }}>
        {STREAMS.map(s => (
          <Card key={s.name} accent={s.color}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:12 }}>
              <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                <span style={{ fontSize:28 }}>{s.icon}</span>
                <div>
                  <div style={{ fontSize:14, fontWeight:700, color:T.white }}>{s.name}</div>
                  <div style={{ fontSize:11, color:s.color, fontWeight:600 }}>{s.revenue}</div>
                </div>
              </div>
              <Pill color={s.type==='Primary'?T.gold:s.type==='Platform'?T.teal:T.muted}>{s.type}</Pill>
            </div>
            <p style={{ fontSize:12, color:T.muted, lineHeight:1.6, marginBottom:12 }}>{s.desc}</p>
            <div style={{ display:'flex', flexDirection:'column', gap:5 }}>
              {s.mechanics.map(m => (
                <div key={m} style={{ fontSize:11, color:T.white, display:'flex', gap:8 }}>
                  <span style={{ color:s.color, flexShrink:0 }}>✦</span>{m}
                </div>
              ))}
            </div>
          </Card>
        ))}
      </div>
    </Section>
  )
}

/* ═══════════════════════════════════════════════════════
   SECTION 7 — 12-MONTH ROADMAP
═══════════════════════════════════════════════════════ */
function Roadmap() {
  const [hover, setHover] = useState<number|null>(null)
  const SPRINTS = [
    { q:'Q1 2025', label:'Foundation Sprint', color:T.nexus, status:'complete',
      milestones:['NEXUS entity formation + $50M seed round','Google Cloud Vertex AI partnership signed','Salesforce OEM Agentforce license','Meta Presence Platform SDK access','Core team 80 engineers hired (SF, London, Nairobi)'],
      kpi:'Architecture v0.1 finalized · Dev environment live' },
    { q:'Q2 2025', label:'Intelligence Core', color:T.google, status:'complete',
      milestones:['Gemini 3 Pro API integration (1M context)','Life Score™ algorithm v1 built on Data Cloud','Llama 4 Scout fine-tuned on social graph data','On-device Gemini Nano privacy layer shipped','Alpha test: 500 internal users'],
      kpi:'Life Score™ accuracy: 87% · Latency: 12ms P99' },
    { q:'Q3 2025', label:'Spatial & Social Layer', color:T.meta, status:'complete',
      milestones:['Meta Presence Platform AR overlay prototype','Dynamic Social Graph engine (Relationship Scores)','Ray-Ban AI glasses beta integration','Spatial Commerce PoC (AR try-on)','Private beta: 10,000 waitlist users'],
      kpi:'Relationship Score engine live · AR latency <40ms' },
    { q:'Q4 2025', label:'Agentic Engine Launch', color:T.sf, status:'complete',
      milestones:['Agentforce autonomous agent fleet deployed','Micro-transaction rails (NEXUS Pay) launched','Creator Revenue OS v1 shipped','Series A: $180M at $1.2B valuation','Public beta: 200,000 users across 12 countries'],
      kpi:'50K DAU · $0.48 ARPU · 94% retention D7' },
    { q:'Q1 2026', label:'Scale & Monetization', color:T.pink, status:'active',
      milestones:['AIaaS tiers (Free/Pro/Business/Enterprise) launched','Life Intelligence API opened to developers','Spatial advertising platform (opt-in) activated','Series B: $400M at $4.5B valuation','2M users · 45 countries'],
      kpi:'2M MAU · $8.20 ARPU · NPS 74' },
    { q:'Q2 2026', label:'Global Expansion', color:T.gold, status:'active',
      milestones:['Quest 3 XR workspace full launch','Portable Social Passport (DID) live','NEXUS OS white-label for enterprises','Strategic acquisition: AI scheduling startup','10M users target · 120 countries'],
      kpi:'10M MAU target · $140M ARR · profitability path' },
    { q:'Q3 2026', label:'Network Effects', color:T.teal, status:'upcoming',
      milestones:['Dunbar 150 Community Gravity Engine™ launch','Life Event Prediction Engine (94.7% accuracy)','Third-party agent marketplace opens','IPO preparation begins (Goldman, Morgan Stanley)','50M users milestone'],
      kpi:'50M MAU · $620M ARR · Virality coefficient >1.3' },
    { q:'Q4 2026', label:'#1 Global App', color:T.google, status:'upcoming',
      milestones:['100M+ MAU (overtakes LinkedIn at 1.1B, racing TikTok)','NEXUS OS becomes dominant enterprise social platform','IPO: target $25B+ valuation','NEXUS declared #1 business app globally (App Annie)','Phase 2: NEXUS Health, NEXUS Finance OS announced'],
      kpi:'#1 Global Business App · $2.1B ARR · $25B valuation' },
  ]

  const statusColor: Record<string,string> = { complete:T.teal, active:T.gold, upcoming:T.muted }
  const statusLabel: Record<string,string> = { complete:'✓ Complete', active:'⚡ Active', upcoming:'◯ Planned' }

  return (
    <Section id="roadmap" style={{ background:T.bg }}>
      <SectionHead
        eyebrow="🗺️ Technical Roadmap"
        title="12-Month Sprint to #1"
        sub="Q4 2025 launch. #1 global business app by Q4 2026. Eight development sprints, each building irreversible competitive moats."
        gradient={`linear-gradient(135deg,${T.nexus},${T.teal})`}
      />
      <div style={{ overflowX:'auto', paddingBottom:8 }}>
        <div style={{ display:'grid', gridTemplateColumns:`repeat(${SPRINTS.length},minmax(200px,1fr))`, gap:12, minWidth:1400 }}>
          {SPRINTS.map((s,i) => (
            <motion.div key={s.q} whileHover={{ y:-4 }} onHoverStart={() => setHover(i)} onHoverEnd={() => setHover(null)}
              style={{ background:hover===i?`${s.color}15`:T.bgGlass, border:`1px solid ${hover===i?s.color:T.border}`, borderRadius:16, padding:'18px 16px', cursor:'default', transition:'all .2s', backdropFilter:'blur(8px)' }}>
              <div style={{ marginBottom:12 }}>
                <div style={{ fontSize:10, fontWeight:700, color:statusColor[s.status], marginBottom:4 }}>{statusLabel[s.status]}</div>
                <div style={{ fontFamily:'Syne,sans-serif', fontSize:14, fontWeight:800, color:s.color }}>{s.q}</div>
                <div style={{ fontSize:12, color:T.white, fontWeight:600, marginTop:2 }}>{s.label}</div>
              </div>
              <div style={{ display:'flex', flexDirection:'column', gap:5, marginBottom:14 }}>
                {s.milestones.map(m => (
                  <div key={m} style={{ fontSize:10, color:T.muted, display:'flex', gap:5, lineHeight:1.4 }}>
                    <span style={{ color:s.color, flexShrink:0 }}>·</span>{m}
                  </div>
                ))}
              </div>
              <div style={{ background:`${s.color}15`, border:`1px solid ${s.color}25`, borderRadius:8, padding:'8px 10px', fontSize:10, color:s.color, lineHeight:1.5 }}>
                🎯 {s.kpi}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </Section>
  )
}

/* ═══════════════════════════════════════════════════════
   SECTION 8 — GENSPARK RESEARCH SUMMARY
═══════════════════════════════════════════════════════ */
function Research() {
  const FINDINGS = [
    {
      category:'Google Infrastructure (2026)',
      color:T.google, icon:'🔵',
      insights:[
        { title:'Gemini Enterprise Agent Platform', detail:'Formerly Vertex AI — rebranded at Google Cloud Next \'26. Includes Gemini 3 Pro (1M token context), TPU 8t (training) and 8i (inference) split architecture. New $750M partner fund announced.' },
        { title:'Virgo AI Network Fabric', detail:'Dedicated AI-optimized network layer separating agentic AI traffic from standard web traffic. Enables sub-1ms orchestration of multi-agent workflows at global scale.' },
        { title:'Agent-to-Agent (A2A) Protocol', detail:'Google\'s 2026 standard for autonomous agent communication. Enables NEXUS agents to negotiate, delegate, and collaborate without human involvement — the core of "Agentic OS" architecture.' },
        { title:'Gemini 2.5 Ultra (Current) → 3 Pro (2026)', detail:'Gemini 2.5 Ultra confirmed adaptive thinking for complex agentic challenges. Gemini 3 Pro expected to ship Q3 2026 with enhanced multimodal reasoning and lower inference cost.' },
      ]
    },
    {
      category:'Salesforce Agentforce (2026)',
      color:T.sf, icon:'☁️',
      insights:[
        { title:'Agentic CRM Paradigm Shift', detail:'2026 industry research confirms: "Clean CRM data creates context, Einstein turns data into intelligence, Agentforce transforms intelligence into autonomous action." This is the NEXUS Life Management Stack.' },
        { title:'Zero-ETL Data Architecture', detail:'Salesforce Data Cloud\'s Zero-ETL architecture eliminates data migration entirely. NEXUS can ingest user data from 200+ sources in real-time with zero engineering overhead.' },
        { title:'Einstein Predictive Intelligence', detail:'5 core benefits identified: lead scoring, churn prediction, revenue forecasting, relationship decay alerts, life event triggers. NEXUS applies all 5 to personal relationship management.' },
        { title:'Agentforce 2.0 Autonomous Workflows', detail:'March 2026 deployment data shows Agentforce reducing manual workflow steps by 73% and increasing CRM-driven revenue by 31% in enterprise deployments. Direct benchmark for NEXUS.' },
      ]
    },
    {
      category:'Meta Spatial Computing (2026)',
      color:T.meta, icon:'🌀',
      insights:[
        { title:'Horizon Worlds Shutdown = Opportunity', detail:'Meta shut down Horizon Worlds from Quest headsets in June 2026 to pivot to AI and Presence Platform SDK. This creates a clear white space for NEXUS Spatial Social to fill with the existing Quest 3 user base.' },
        { title:'Llama 4 Open Ecosystem', detail:'2026 analysis confirms Meta\'s Llama ecosystem is now "the architect of the open AI world." Llama 4 Scout enables NEXUS to run sophisticated social intelligence entirely on-device with no cloud dependency.' },
        { title:'Quest 3 Enterprise Dominance', detail:'Quest 3 recognized as "the most balanced mixed reality headset for enterprise use in 2026" by Groove Jones. NEXUS XR Workspace targets this installed base directly.' },
        { title:'Ray-Ban Smart Glasses Mainstream', detail:'Ray-Ban AI glasses (Meta collaboration) reaching mainstream adoption in 2026. NEXUS AR overlay is the killer app that drives 15% of new user acquisition through word-of-mouth demos.' },
      ]
    },
    {
      category:'Competitive Landscape (2026 Data)',
      color:T.pink, icon:'📊',
      insights:[
        { title:'Algorithmic Reach Collapse', detail:'Q1 2026: average social media reach declined 22% across 1,200 campaigns. Engagement rates down 11% even with same influencers. The algorithm-as-moat is crumbling — NEXUS direct relationship model benefits.' },
        { title:'Gen Z TikTok-Google Shift', detail:'Adobe Express data: Gen Z preference for TikTok over Google for search dropped 50% (8% to 4%) between 2024 and 2026. Signal of intent to switch to intelligence-first platforms like NEXUS.' },
        { title:'Interest Graph Kills Social Graph', detail:'2026 industry analysis confirms all major platforms shifted from social-graph to interest-graph distribution — alienating users who came for connection. NEXUS Dunbar 150™ restores genuine social graph primacy.' },
        { title:'Creator Monetization Crisis', detail:'Creators earn <$0.02/1K views on TikTok. Instagram Reels pays 80% less than YouTube. NEXUS\'s 85% creator revenue share and micro-transaction rails are a structural competitive advantage for talent acquisition.' },
      ]
    },
  ]

  return (
    <Section id="research" style={{ background:`linear-gradient(180deg,${T.bgCard},${T.bg})` }}>
      <SectionHead
        eyebrow="📡 Genspark Research Summary"
        title="Emerging Technology Intelligence"
        sub="Real 2026 research findings across all four technology domains — confirming NEXUS's technical assumptions and revealing timing windows for market entry."
        gradient={`linear-gradient(135deg,${T.teal},${T.nexus})`}
      />
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:24 }}>
        {FINDINGS.map(f => (
          <Card key={f.category} accent={f.color}>
            <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:20 }}>
              <span style={{ fontSize:28 }}>{f.icon}</span>
              <h3 style={{ fontFamily:'Syne,sans-serif', fontSize:17, fontWeight:800, color:T.white }}>{f.category}</h3>
            </div>
            <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
              {f.insights.map(ins => (
                <div key={ins.title} style={{ borderLeft:`2px solid ${f.color}40`, paddingLeft:14 }}>
                  <div style={{ fontSize:13, fontWeight:700, color:f.color, marginBottom:4 }}>{ins.title}</div>
                  <div style={{ fontSize:12, color:T.muted, lineHeight:1.6 }}>{ins.detail}</div>
                </div>
              ))}
            </div>
          </Card>
        ))}
      </div>
    </Section>
  )
}

/* ═══════════════════════════════════════════════════════
   SECTION 9 — SECURITY & PRIVACY
═══════════════════════════════════════════════════════ */
function Security() {
  const PRINCIPLES = [
    {
      title:'Data Sovereignty First',
      icon:'🏛️', color:T.nexus,
      desc:'Users own their data. Full export, deletion, and portability guaranteed by design — not by policy. NEXUS operates on derived AI insights, never raw personal data at the API layer.',
      specs:['AES-256 encryption at rest','TLS 1.3 in transit (Mutual TLS for agents)','Zero-Knowledge Architecture for Life Score™','GDPR, CCPA, PDPA multi-jurisdiction compliance']
    },
    {
      title:'Salesforce × Meta Privacy Bridge',
      icon:'🔐', color:T.sf,
      desc:'The hardest technical challenge: merging Salesforce private CRM data with Meta social graph without creating a surveillance apparatus. Solution: Federated Learning + Differential Privacy.',
      specs:['Federated Learning — AI trains on-device, only gradients shared','Differential Privacy — all Data Cloud queries add calibrated noise','No cross-platform raw data joins (only derived signals)','Third-party audit: PwC quarterly privacy attestation']
    },
    {
      title:'Agentic AI Safety Framework',
      icon:'🛡️', color:T.google,
      desc:'Autonomous agents that take real-world actions require strict safety guardrails. NEXUS implements a 4-tier action authorization model with mandatory human confirmation for high-stakes decisions.',
      specs:['Tier 1 (auto): Read, draft, analyze','Tier 2 (confirm): Send, schedule, publish','Tier 3 (explicit): Pay, contract, delete','Tier 4 (MFA): Financial transfers >$100']
    },
    {
      title:'Spatial Privacy in AR Mode',
      icon:'👓', color:T.meta,
      desc:'AR facial context and location data never leave the device unencrypted. NEXUS uses Gemini Nano + Llama 4 for all spatial inference — zero cloud round-trips for real-world identification.',
      specs:['On-device only face+context recognition','AR data ephemeral — not logged to cloud','Location data: differential privacy radius 50m','Bystander privacy mode: blur unconnected people']
    },
    {
      title:'Regulatory Compliance Matrix',
      icon:'⚖️', color:T.gold,
      desc:'NEXUS is designed for the strictest global compliance from day one — EU AI Act (effective 2025), UK Online Safety Act, India PDPB, and anticipated US federal AI regulation.',
      specs:['EU AI Act: High-Risk AI System certified','SOC 2 Type II (annual)','ISO 27001 + ISO 42001 (AI Management)','Bug bounty: $1M max payout program']
    },
    {
      title:'Anti-Manipulation Design',
      icon:'🚫', color:T.pink,
      desc:'NEXUS refuses to implement engagement-maximization dark patterns. All algorithms are optimized for user Life Outcomes™ (career success, relationship quality, wellbeing) — not time-on-app.',
      specs:['No infinite scroll — session time limits configurable','Algorithmic transparency: explain any feed decision','No opt-out manipulation for data sharing','External ethics board (6 independent members)']
    },
  ]

  return (
    <Section id="security" style={{ background:T.bg, paddingBottom:120 }}>
      <SectionHead
        eyebrow="🔒 Security & Data Privacy"
        title="Privacy-Native Architecture"
        sub="Merging Salesforce private CRM data with Meta social data is the biggest regulatory and technical hurdle in 2026. NEXUS solves it with federated learning and differential privacy — making surveillance architecturally impossible."
        gradient={`linear-gradient(135deg,${T.nexus},${T.teal})`}
      />
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(320px,1fr))', gap:20 }}>
        {PRINCIPLES.map(p => (
          <Card key={p.title} accent={p.color}>
            <div style={{ fontSize:32, marginBottom:12 }}>{p.icon}</div>
            <h3 style={{ fontSize:16, fontWeight:700, color:T.white, marginBottom:8 }}>{p.title}</h3>
            <p style={{ fontSize:13, color:T.muted, lineHeight:1.6, marginBottom:14 }}>{p.desc}</p>
            <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
              {p.specs.map(s => (
                <div key={s} style={{ fontSize:11, color:T.white, display:'flex', gap:8 }}>
                  <span style={{ color:p.color }}>✓</span>{s}
                </div>
              ))}
            </div>
          </Card>
        ))}
      </div>

      {/* Final CTA */}
      <motion.div initial={{ opacity:0, y:24 }} whileInView={{ opacity:1, y:0 }} viewport={{ once:true }}
        style={{ marginTop:72, textAlign:'center', background:`radial-gradient(ellipse 80% 80% at 50% 50%, rgba(108,99,255,0.15), transparent)`, border:`1px solid rgba(108,99,255,0.2)`, borderRadius:28, padding:'56px 48px' }}>
        <div style={{ fontFamily:'Syne,sans-serif', fontSize:'clamp(28px,5vw,52px)', fontWeight:900, letterSpacing:'-1.5px', background:T.nexusG, WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent', backgroundClip:'text', marginBottom:16 }}>
          NEXUS: #1 Global App by Q4 2026
        </div>
        <p style={{ fontSize:16, color:T.muted, maxWidth:600, margin:'0 auto 32px', lineHeight:1.7 }}>
          The convergence of Google's Antigravity Infrastructure, Salesforce's Predictive Intelligence, and Meta's Spatial Social layer creates a super-app that incumbents cannot replicate without rebuilding everything they have.
        </p>
        <div style={{ display:'flex', gap:16, justifyContent:'center', flexWrap:'wrap' }}>
          {[
            { label:'Seed Round', value:'$50M', color:T.nexus },
            { label:'Series A', value:'$180M', color:T.teal },
            { label:'Series B', value:'$400M', color:T.gold },
            { label:'IPO Target', value:'$25B+', color:T.pink },
          ].map(f => (
            <div key={f.label} style={{ background:`${f.color}15`, border:`1px solid ${f.color}30`, borderRadius:16, padding:'16px 24px', textAlign:'center' }}>
              <div style={{ fontFamily:'Syne,sans-serif', fontSize:24, fontWeight:900, color:f.color }}>{f.value}</div>
              <div style={{ fontSize:11, color:T.muted, marginTop:4 }}>{f.label}</div>
            </div>
          ))}
        </div>
      </motion.div>
    </Section>
  )
}

/* ═══════════════════════════════════════════════════════
   STICKY NAV
═══════════════════════════════════════════════════════ */
function StickyNav() {
  const [active, setActive] = useState('overview')
  const [open, setOpen] = useState(false)
  useEffect(() => {
    const obs = new IntersectionObserver(entries => {
      entries.forEach(e => { if (e.isIntersecting) setActive(e.target.id) })
    }, { threshold:.3, rootMargin:'-80px 0px -60% 0px' })
    NAV_ITEMS.forEach(n => { const el = document.getElementById(n.id); if(el) obs.observe(el) })
    return () => obs.disconnect()
  },[])

  return (
    <nav style={{ position:'fixed', top:0, left:0, right:0, zIndex:999, background:'rgba(3,7,18,0.85)', backdropFilter:'blur(16px)', borderBottom:`1px solid rgba(255,255,255,0.06)`, padding:'0 clamp(12px,3vw,40px)', height:56, display:'flex', alignItems:'center', justifyContent:'space-between' }}>
      <a href="/" style={{ fontFamily:'Syne,sans-serif', fontSize:16, fontWeight:800, color:T.white, textDecoration:'none', display:'flex', alignItems:'center', gap:8 }}>
        <span style={{ background:T.nexusG, WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent', backgroundClip:'text' }}>NEXUS</span>
        <span style={{ fontSize:10, color:T.muted, fontWeight:400 }}>Blueprint 2026</span>
      </a>
      <div style={{ display:'flex', gap:2, overflowX:'auto' }}>
        {NAV_ITEMS.map(n => (
          <a key={n.id} href={`#${n.id}`}
            style={{ padding:'6px 12px', borderRadius:8, fontSize:11, fontWeight:600, color:active===n.id?T.white:T.muted, background:active===n.id?'rgba(108,99,255,0.2)':'transparent', textDecoration:'none', transition:'all .2s', whiteSpace:'nowrap', display:'flex', alignItems:'center', gap:5 }}
            onClick={e => { e.preventDefault(); document.getElementById(n.id)?.scrollIntoView({ behavior:'smooth' }) }}>
            <span style={{ fontSize:13 }}>{n.icon}</span>
            <span style={{ display:'block' }}>{n.label}</span>
          </a>
        ))}
      </div>
    </nav>
  )
}

/* ═══════════════════════════════════════════════════════
   ROOT EXPORT
═══════════════════════════════════════════════════════ */
export default function SuperApp() {
  return (
    <div style={{ background:T.bg, minHeight:'100vh', color:T.white, fontFamily:`'DM Sans',ui-sans-serif,system-ui,sans-serif` }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@700;800;900&family=DM+Sans:wght@300;400;500;600&display=swap');
        @keyframes float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-18px)} }
        html { scroll-behavior: smooth; }
        * { box-sizing: border-box; margin:0; padding:0; }
        ::-webkit-scrollbar { width:4px; height:4px; }
        ::-webkit-scrollbar-track { background:${T.bg}; }
        ::-webkit-scrollbar-thumb { background:rgba(108,99,255,0.4); border-radius:2px; }
        ::selection { background:rgba(108,99,255,0.3); }
      `}</style>
      <StickyNav />
      <HeroSection />
      <GapAnalysis />
      <Architecture />
      <HolyTrinity />
      <UXFlow />
      <Monetization />
      <Roadmap />
      <Research />
      <Security />
    </div>
  )
}
