# easyTenancy Global OS

> **The #1 Global Real Estate Operating System** — AI-powered property management for landlords, tenants, and agents across 120+ countries. Built with the Holy Trinity: Google Gemini · Salesforce Agentforce · Meta Presence Platform.

## 🌐 Live URLs

| Route | URL | Status |
|-------|-----|--------|
| **Production** | [easy-tenancy-global-os.pages.dev](https://easy-tenancy-global-os.pages.dev/) | ✅ Live |
| **App Demo** | [/app/demo](https://easy-tenancy-global-os.pages.dev/app/demo) | ✅ Live |
| **Global Dominance** | [/global-dominance](https://easy-tenancy-global-os.pages.dev/global-dominance) | ✅ Live |
| **Predictive OS** | [/predictive-os](https://easy-tenancy-global-os.pages.dev/predictive-os) | ✅ Live |
| **Spatial Staging** | [/spatial-staging](https://easy-tenancy-global-os.pages.dev/spatial-staging) | ✅ Live |
| **Security Demo** | [/security-demo](https://easy-tenancy-global-os.pages.dev/security-demo) | ✅ Live |
| **NEXUS Blueprint** | [/nexus](https://easy-tenancy-global-os.pages.dev/nexus) | ✅ Live |

## 🗺️ Route Architecture

```
/                    → HomePage          — AI marketing + Hero + ROI Calculator
/app/demo            → AppDemo           — 6-tab property dashboard
/global-dominance    → GlobalDominance   — Holy Trinity blueprint (Google/SF/Meta)
/predictive-os       → PredictiveLifeOS  — AI/CRM/Agentforce dashboard
/spatial-staging     → SpatialStaging    — Novita FLUX.1 AR/VR property staging
/security-demo       → SecurityDemoPage  — Cloudflare Turnstile + WebAuthn FIDO2
/nexus               → SuperApp          — NEXUS Global Dominance 2026 blueprint
/org/:id/properties/:propId/:section → PropertyDetail
/org/:id/ai-copilot  → AppDemo (copilot entry)
```

## 🚀 Key Features

### Platform Core
- **AI Lease Management** — AI-drafted leases, e-signatures, auto-renewals, multi-country compliance
- **Smart Rent Collection** — Automated reminders, multi-currency (KES/GBP/AED/USD), bank reconciliation
- **Maintenance Hub** — Issue tracking, contractor dispatch, cost analytics
- **Portfolio Analytics** — ROI dashboards, occupancy rates, yield optimization, Predictive Life OS

### Advanced Components
- **GlobalOrchestrator** — 14-component agentic event bus with AI routing
- **ComplianceEngine** — Multi-jurisdiction legal compliance (KE/UK/AE)
- **WebAuthnLogin** — FIDO2 passkey biometric auth (Touch ID / Face ID / Windows Hello)
- **TurnstileWidget** — Cloudflare invisible bot protection (CAPTCHA-free)
- **SpatialStaging** — Novita AI FLUX.1 img2img AR/VR property visualization
- **MetricsTicker** — Live global portfolio metrics feed
- **RadialMap** — D3-powered global market visualization
- **ROICalculator** — Real-time ROI analysis with AI projections
- **AICopilot** — GPT-powered property management assistant

### NEXUS Blueprint (`/nexus`)
**Global Dominance 2026 Super-App** — Interactive 9-section master plan:
1. **Hero** — $935B market, 1.4B AR/VR users, live KPI counters
2. **Gap Analysis** — TikTok/Instagram/LinkedIn competitor weaknesses
3. **Architecture** — 5-layer: Google Edge → Intelligence Core → Salesforce CRM → Meta Spatial → NEXUS Shell
4. **Holy Trinity** — Google Antigravity/Gemini/Vertex + Salesforce Einstein/Agentforce/Data Cloud + Meta Presence/Llama/Social Graph
5. **UX Flow** — 6-step user journey with Framer Motion animations
6. **Monetization** — 6 revenue streams, $935B TAM breakdown
7. **Roadmap** — 8-sprint horizontal board Q1 2025→Q4 2026
8. **Research** — Real 2026 data (Google Cloud Next '26, Salesforce AI, Meta Quest)
9. **Security** — Federated learning + differential privacy + 4-tier agentic safety

### Footer — Expandable Accordion
6 sections × 8 rich links = **48 rich marketing links** with descriptions + badges:
- Product · Markets · Solutions · Academy · Resources · Company
- easyTenancy Academy highlight banner (4 stats: 2,400+ students, 18 courses, 94% completion, 4.9★)

## 🏗️ Architecture

```
React 18 + Vite 6.4.2 + TypeScript
├── React Router v6 (BrowserRouter, full SPA)
├── Framer Motion 11 (page transitions, whileInView, AnimatePresence)
├── Hono 4.x (CF Pages Functions)
├── D3 sub-packages (force, selection, scale, zoom, drag)
├── Cloudflare Pages (global edge — 300+ PoPs)
│
src/
├── lib/
│   ├── tokens.ts           # Design tokens (BRAND, FONTS, GRADIENTS)
│   ├── GlobalOrchestrator.ts # 14-component agentic event bus
│   ├── ComplianceEngine.ts # Multi-jurisdiction legal engine
│   ├── demoData.ts         # Multi-tenant demo data (KE/UK/AE)
│   ├── wsStream.ts         # WebSocket streaming utilities
│   └── schemas.ts          # Zod validation schemas
├── components/
│   ├── Logo.tsx            # Responsive logo (sm/md/lg/xl variants)
│   ├── Nav.tsx             # Sticky nav + NEXUS Blueprint link
│   ├── Footer.tsx          # 6-section expandable accordion footer
│   ├── AICopilot.tsx       # GPT property assistant
│   ├── WebAuthnLogin.tsx   # FIDO2 passkey auth
│   ├── TurnstileWidget.tsx # Cloudflare bot protection
│   ├── SpatialStaging.tsx  # Novita AR/VR staging
│   ├── RadialMap.tsx       # D3 global market map
│   ├── MetricsTicker.tsx   # Live metrics feed
│   ├── ROICalculator.tsx   # AI ROI projections
│   ├── CompliancePanel.tsx # Multi-jurisdiction compliance UI
│   ├── FeatureMicroTours.tsx # Guided feature tours
│   ├── AIFeed.tsx          # Real-time AI insights feed
│   ├── HeroStateWidget.tsx # Hero CTA with live state
│   └── ActionableIntelligence.tsx # AI recommendations engine
└── routes/
    ├── HomePage.tsx        # Marketing landing page
    ├── AppDemo.tsx         # 6-tab dashboard demo
    ├── GlobalDominance.tsx # Holy Trinity blueprint
    ├── PredictiveLifeOS.tsx # AI/CRM Agentforce dashboard
    ├── PropertyDetail.tsx  # Deep property analytics
    └── SuperApp.tsx        # NEXUS Blueprint (63KB)
```

## 📦 Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18.3 + TypeScript |
| Build | Vite 6.4.2 + code splitting |
| Routing | React Router v6 |
| Animation | Framer Motion 11 |
| Backend | Hono 4.x (CF Workers Functions) |
| Security | Cloudflare Turnstile + WebAuthn FIDO2 |
| AI | Novita AI (FLUX.1 img2img) + GPT Copilot |
| Deploy | Cloudflare Pages (300+ global PoPs) |
| Dev Server | Node.js + PM2 (sandbox) |

## 🌍 Market Coverage

| Country | Currency | Accent |
|---------|----------|--------|
| Kenya 🇰🇪 | KES | `#2A9D6E` teal |
| United Kingdom 🇬🇧 | GBP | `#1A6DB5` blue |
| UAE 🇦🇪 | AED | `#f59e0b` amber |
| United States 🇺🇸 | USD | `#2A9DE8` sky |
| Nigeria 🇳🇬 | NGN | `#10b981` green |
| South Africa 🇿🇦 | ZAR | `#a78bfa` purple |

## 🛠️ Development

```bash
# Install dependencies
npm install

# Build for production
npm run build

# Start dev server (PM2)
pm2 start ecosystem.config.cjs

# Deploy to Cloudflare Pages
export CLOUDFLARE_ACCOUNT_ID=db2401e3c3e1c4eca512965bfe801f92
npx wrangler pages deploy dist --project-name easy-tenancy-global-os
```

## 🔒 Security & Compliance

- **Cloudflare Turnstile** — Invisible bot protection, GDPR compliant, CCPA compliant
- **WebAuthn FIDO2** — Passkey biometric auth, phishing-proof, SOC 2 certified
- **Federated Learning** — Privacy-preserving AI training (Salesforce × Meta bridge)
- **Differential Privacy** — Mathematical privacy guarantees for CRM data
- **Multi-jurisdiction** — KE Data Protection Act, UK GDPR, UAE PDPL compliance

See [SECURITY.md](./SECURITY.md) for vulnerability reporting guidelines.

## 📅 Version History

| Version | Notes |
|---------|-------|
| v1.0.0 | Full rebuild: brand system + expandable footer + PWA |
| v1.1.0 | NEXUS Global Dominance 2026 Blueprint at `/nexus` |
| v1.2.0 | Global Hegemony 2.0 — Sovereign Economic OS: GlobalOrchestrator, WebAuthn, Turnstile, Novita AI |
| v1.3.0 | Merged: SuperApp + Footer accordion + NEXUS route into advanced codebase |

---

**Platform**: Cloudflare Pages · **Project**: `easy-tenancy-global-os` · **CF Account**: `db2401e3c3e1c4eca512965bfe801f92`
